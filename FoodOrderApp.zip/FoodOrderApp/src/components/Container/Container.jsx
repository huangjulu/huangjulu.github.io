import MealItem from "./MealItem/MealItem";

export default function Container() {
    return (
        <div id="meals">
            <MealItem />
        </div>
    )
}